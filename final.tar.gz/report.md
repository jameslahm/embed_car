### 大作业文档

#### 功能模块

##### 完成情况

- [x] 前进1m后停止
- [x] 后退1m后停止
- [x] 左转后停止，夹角大于90小于180度
- [x] 右转后停止，夹角大于90小于180度

##### 算法说明

首先记录当前状态，初始状态为前进状态，同时根据当前速度记录已行驶距离，在每20ms周期内检测是否达到距离，达到则进入停止状态，停止状态使用计数器记录已停止时间，达到时间后进入后退状态，达到距离后进入停止状态，接着进入左转状态，左转时使用左右轮脉冲数控制转向角度，达到角度后进入停止状态，接着进入右转状态，与左转类似，最后进入停止状态。

#### 循线避障

##### 完成情况

- [x] 红外循线部分
- [x] 避障部分
- [ ] 停止部分

##### 算法说明

###### 测试版本（转向90度，适用于简单赛道）

首先记录当前状态，初始为循迹状态，每20ms内根据红外探测电平调整转向以跟随黑线前进，当四个方向都检测到黑线时，进入循线与避障间的过渡状态，前进越过停止线后，进入避障状态，每20ms内根据超声波探测距离更新避障状态，若当前距离小于10cm，则进行后退，若在20-30cm之间，则进入转向状态，若大于30cm，则进入直行状态，转向时先右转90度，看是否能直行，若可以，则继续直行，若不可，则左转90度后，查看是否可直行，若不可，则再左转90度，查看是否可直行，若不可，则再右转90度查看是否可直行，由于赛道障碍物的摆放位置，在转向中会最终进入直行状态，最后当检测到四个方向黑线时，则停止。

###### 小角度探测版本（使用小角度探测，适用于复杂赛道）

首先记录当前状态，初始为循迹状态，每20ms内根据红外探测电平调整转向以跟随黑线前进，当四个方向都检测到黑线时，进入循线与避障间的过渡状态，前进越过停止线后，进入避障状态，每20ms内根据超声波探测距离更新避障状态，若当前距离小于10cm，则进行后退，若在20-30cm之间，则进入转向状态，若大于30cm，则进入直行状态，转向时依次右转，看当前角度是否能直行，若可以，则直接进入直行状态，若一直转到右方90度依然不可直行，则调整转向，开始向左探测，依次左转，查看当前角度是否可直行，若可以则直接直行，若一直转到左方90度依然不可直行，则调整转向，开始向右探测，循环往复，由于赛道必然可前行，在转向中会最终进入直行状态，最后当检测到四个方向黑线时，则停止。

###### 其他说明（直行修正，角度记录，卡轮，卡住，异常距离探测处理等情况）

- 直行修正问题：由于小车直行时可能会偏，需在直行状态时根据左右轮速度差进行修正，同时使用角速度进行修正
- 角度记录问题：使用陀螺仪进行角度偏向的计算

- 卡轮问题：每次检测当前速度与上一次速度差，若超过一定阈值，则判断当前被卡轮，进入强制后退，接着强制转向状态，以避免卡轮状态
- 卡住问题：每次检测是否当前一直处于低速状态一段时间，若是，则判断为被卡住，进入强制后退，接着强制转向状态
- 异常距离探测问题：由于超声波测距本身的不稳定性，对于超声波异常距离值，会直接略过，同时对距离进行平滑处理，以保证探测距离的稳定性和平滑性



#### 代码说明文档

代码集于助教已给的基础示例，主要在`control.c`，`main.c`，`manage.h`，`manage.c`中进行修改，修改部分如下

- `manage.c`：修改当前模式

  ```c
  unsigned char g_CarRunningMode = REPORT_MODE_ONE;
  ```

- `manage.h`：添加额外模式

  ```c
  #define CONTROL_MODE 			1
  #define INFRARED_TRACE_MODE 	2
  #define ULTRA_FOLLOW_MODE		3
  #define ULTRA_AVOID_MODE	   4
  // 大作业第一部分模式
  #define REPORT_MODE_ONE 5
  // 大作业第二部分模式
  #define REPORT_MODE_TWO 6
  ```

- `main.c`：根据不同模式调用不同控制函数

  ```c
  if(g_CarRunningMode == ULTRA_FOLLOW_MODE){
      if(IsUltraOK())UltraControl(0);	//超声波跟随模式
  }
  else if(g_CarRunningMode == ULTRA_AVOID_MODE){
      if(IsUltraOK())UltraControl(1);	//超声波避障模式
  }
  else if(g_CarRunningMode == INFRARED_TRACE_MODE){
      TailingControl();
  } else if(g_CarRunningMode == REPORT_MODE_ONE) {
      ReportModeOneControl(); // 大作业第一部门
  } else if(g_CarRunningMode == REPORT_MODE_TWO){
      ReportModeTwoControl(); // 大作业第二部门
  }
  ```

- `control.c`：添加控制函数

##### 功能模块代码说明

```c
#define FORWARD 0
#define FORWARD_STOP 1
#define BACK 2
#define BACK_STOP 3
#define LEFT_TURN 4
#define LEFT_TURN_STOP 5
#define RIGHT_TURN 6
#define RIGHT_TURN_STOP 7

// 初始化状态为前进1m
int report_mode_one_status = FORWARD;
// 计时 主要用于停止计时
int report_mode_one_timer = 0;

// 用于记录停止时长
void ResetReportOneTimer() { report_mode_one_timer = 0; }
void IncReportOneTimer() { report_mode_one_timer += 20; }

// 记录当前行驶距离
float g_Distance = 0;
// 记录上一次速度，用于平滑
float g_speed_old = 0;
// 记录是否进行过左转
int left_turn_start = 1;
// 记录是否进行过右转
int right_turn_start = 1;
// 控制函数
void ReportModeOneControl(void)
{
  float current_speed;
  switch (report_mode_one_status)
  {
  // 首先前行
  case FORWARD:
  {
    // 记录达到1.1m后 后退
    if (g_Distance > 1.1)
    {
      report_mode_one_status = FORWARD_STOP;
      g_Distance = 0;
      g_speed_old = 0;
      ResetReportOneTimer();
      Steer(0, 0);
    }
    // 否则一直前进
    else
    {
      Steer(0, 4);
      current_speed = (g_speed_old + g_fCarSpeed) * 0.5;
      g_speed_old = g_fCarSpeed;
      g_Distance += (current_speed * 0.01) * 0.02;
    }
    break;
  }
  // 后退
  case BACK:
  {
    // 后退达到距离后，左转
    if (g_Distance < -1.1)
    {
      report_mode_one_status = BACK_STOP;
      g_Distance = 0;
      g_speed_old = 0;
      ResetReportOneTimer();
      Steer(0, 0);
    }
    else
    {
      Steer(0, -3);
      current_speed = (g_speed_old + g_fCarSpeed) * 0.5;
      g_speed_old = g_fCarSpeed;
      g_Distance += (current_speed * 0.01) * 0.02;
    }
    break;
  }
  // 进入左转状态
  case LEFT_TURN:
  {
    if (left_turn_start == 1)
    {
      Steer(-1, 4);
      // g_iLeftTurnRoundCnt = -750;
      g_iRightTurnRoundCnt = 5000;
      left_turn_start = 0;
    }

    if (g_iRightTurnRoundCnt < 0)
    {
      report_mode_one_status = LEFT_TURN_STOP;
      ResetReportOneTimer();
      Steer(0, 0);
    }
    break;
  }
  // 进入右转状态
  case RIGHT_TURN:
  {
    if (right_turn_start == 1)
    {
      Steer(1, 4);
      g_iLeftTurnRoundCnt = 5000;
      // g_iRightTurnRoundCnt = -750;
      right_turn_start = 0;
    }
    if (g_iLeftTurnRoundCnt < 0)
    {
      report_mode_one_status = RIGHT_TURN_STOP;
      ResetReportOneTimer();
      Steer(0, 0);
    }
    break;
  }
  // 进入停止状态
  case FORWARD_STOP:
  case BACK_STOP:
  case LEFT_TURN_STOP:
  case RIGHT_TURN_STOP:
  {
    if (report_mode_one_timer > 1000)
    {
      if (report_mode_one_status == FORWARD_STOP)
      {
        report_mode_one_status = BACK;
      }
      else if (report_mode_one_status == BACK_STOP)
      {
        report_mode_one_status = LEFT_TURN;
      }
      else if (report_mode_one_status == LEFT_TURN_STOP)
      {
        report_mode_one_status = RIGHT_TURN;
      }
      else if (report_mode_one_status == RIGHT_TURN_STOP)
      {
      }
      ResetReportOneTimer();
    }
    else
    {
      IncReportOneTimer();
    }
    break;
  }
  }
}
```

##### 循线避障代码说明

###### 小角度探测版本

```c
// 记录小车避障状态
#define DISTANCE_FORWARD 0
#define DISTANCE_BACKWARD 1
#define DISTANCE_TURN 2
#define FORCED_BACKWARD 3
#define FORCED_TURN 4

// 初始状态为循迹
int report_mode_two_status = TRACE;
// 当前转向，1为右，-1为左
int current_direction = 1;
// 转向速度
int rotate_speed = 1;
// 记录超声波距离差，用于检测异常状态
int delta_distance = 0;
// 上一次超声波探测距离
int distance_old = -1;
// 修正距离，对超声波探测距离进行平滑处理
int fixed_distance = 0;
// 记录小车避障状态
int distance_status = DISTANCE_FORWARD;
// 记录小车上一次状态
int distance_status_old = DISTANCE_FORWARD;
// 强制后退计数，用于处理卡轮情况
int backward_counter = 0;
// 强制转向计数，用于处理卡轮情况
int turn_counter = 0;
// 卡住计数器，判断是否已被卡住
int stop_counter = 0;
// 多转计数器，用于在转向时多转以躲避障碍物
int finetune_counter = 0;
// 记录速度差，检测异常情况
float delta_speed = 0;
// 进入避障初始状态计数器
int left_barriar_counter = 80;

// 小角度探测版本，用于复杂赛道
void ReportModeTwoControl()
{
  // 首先寻迹进入赛道区
  char result;

  // 检测是否要进入避障或停止状态
  result = InfraredDetect();
  if ((result & infrared_channel_La) && (result & infrared_channel_Ra) && (result & infrared_channel_Lb) && (result & infrared_channel_Rb) && (result & infrared_channel_Lc) && (result & infrared_channel_Rc))
  {
    if (report_mode_two_status == TRACE)
    {
      report_mode_two_status = AVOID_BARRIAR;
    }
    else if (report_mode_two_status == AVOID)
    {
      report_mode_two_status = STOP;
    }
  }

  // 进入循迹
  if (report_mode_two_status == TRACE)
  {
    float direct = 0;
    float speed = 0;

    speed = 3;
    
    // 根据红外探测电平高低，调整方向
    //if (result & infrared_channel_Lc)
    // direct = -10;
    // if (result & infrared_channel_Lb)
    // direct = 0;
    if (result & infrared_channel_La)
      direct = -4;
    //else if (result & infrared_channel_Rc)
    // direct = 10;
    // else if (result & infrared_channel_Rb)
    // direct = 6;
    else if (result & infrared_channel_Ra)
      direct = 4;
    else
      direct = 0.0;

    Steer(direct, speed);
  }

  // 避障前直行状态，以越过黑线
  if (report_mode_two_status == AVOID_BARRIAR)
  {
    if (left_barriar_counter >= 0)
    {
      Steer(0, 4);
      left_barriar_counter--;
    }
    else
    {
      report_mode_two_status = AVOID;
    }
  }

  // 进入避障区
  if (report_mode_two_status == AVOID)
  {

    if (distance_old == -1)
    {
      fixed_distance = Distance;
      distance_old = Distance;
    }
    // 平滑超声波探测距离
    else if (Distance <= 400)
    {
      if (distance_status == DISTANCE_TURN || distance_status == FORCED_TURN)
      {
        distance_old = fixed_distance;
        fixed_distance = Distance;
      }
      else
      {
        distance_old = fixed_distance;
        fixed_distance = 0.8 * distance_old + 0.2 * Distance;
      }
    }
    char buffer[40];
    sprintf(buffer, "status:%d distance:%d speed:%.3f ", distance_status, fixed_distance, g_fCarSpeed);
    Uart1SendStr(buffer);

    // 判断异常距离检测
    delta_distance = fixed_distance - distance_old;
    distance_old = fixed_distance;
    delta_speed = g_fCarSpeed - speed_old_2;
    // 卡轮情况，进入强制后退状态
    if (delta_speed <= -8 && distance_status == DISTANCE_FORWARD)
    {
      distance_status = FORCED_BACKWARD;
    }
    // 强制后退，接着强制变向
    if (distance_status == FORCED_BACKWARD)
    {
      if (backward_counter <= 25)
      {
        Steer(0, -4);
        backward_counter++;
      }
      else
      {
        backward_counter = 0;
        distance_status_old = distance_status;
        distance_status = FORCED_TURN;
      }
      return;
    }
    // 强制变向
    else if (distance_status == FORCED_TURN)
    {
      if (turn_counter <= 25)
      {
        if (90 + g_fxyAngle <= 0 && current_direction == 1)
        {
          current_direction = -current_direction;
        }
        if (90 + g_fxyAngle >= 180 && current_direction == -1)
        {
          current_direction = -current_direction;
        }
        Steer(current_direction * rotate_speed, 0);
        turn_counter++;
      }
      else
      {
        turn_counter = 0;
        distance_status_old = distance_status;
        distance_status = DISTANCE_FORWARD;
      }
      return;
    }
    // 距离异常，跳过
    if (delta_distance > 25)
    {
    }
    else
    {
      // 根据距离，更新状态
      if (fixed_distance <= 10 || fixed_distance > 500)
        distance_status = DISTANCE_BACKWARD;
      else if (fixed_distance >= 20 && fixed_distance < 30)
        distance_status = DISTANCE_TURN;
      else if (fixed_distance >= 30)
      {
        // 检测是否长时间低速，若是，则判断为卡住，进入强制后退
        if (g_fCarSpeed <= 3)
          stop_counter++;
        else
          stop_counter = 0;
        if ((g_fGyroAngleSpeed_z > 60 || g_fGyroAngleSpeed_z < -60) || stop_counter >= 50)
        {
          distance_status = FORCED_BACKWARD;
          stop_counter = 0;
        }
        else
          // 进入前进状态
          distance_status = DISTANCE_FORWARD;
      }
    }

    if (distance_status == DISTANCE_BACKWARD)
    {
      Steer(0, -4);
      distance_status_old = distance_status;
    }
    else if (distance_status == DISTANCE_TURN)
    {
      // 变向时，进行小角度探测
      float angle = 90 + g_fxyAngle;
      // 只在以前进方向正负90度内探测，否则变向
      if (angle <= 0 && current_direction == 1)
      {
        current_direction = -current_direction;
      }
      if (angle >= 180 && current_direction == -1)
      {
        current_direction = -current_direction;
      }
      Steer(current_direction * rotate_speed, 0);
      distance_status_old = distance_status;
    }
    else
    {
      // 小角度探测成功后，多转以避免障碍物
      if (distance_status_old == DISTANCE_TURN)
      {
        if (finetune_counter <= 12)
        {
          float angle = 90 + g_fxyAngle;
          if (angle <= 0 && current_direction == 1)
          {
            current_direction = -current_direction;
          }
          if (angle >= 180 && current_direction == -1)
          {
            current_direction = -current_direction;
          }
          Steer(current_direction * rotate_speed, 0);
          finetune_counter++;
        }
        else
        {
          finetune_counter = 0;
          distance_status_old = distance_status;
        }
      }
      else
      {
        Steer(0, 4);
      }
    }
  }

  // 停止状态
  if (report_mode_two_status == STOP)
  {
    Steer(0, 0);
  }
  //
}
```

###### 转向90度版本

> 由于大部分代码与小角度版本相同，这里只展示不同部分

```c
// 判断当前是否在直行，向左前行，向右前行三个状态
int is_direct=1;
is_direct= (abs(txy_Angle + 90) < 5 || abs(txy_Angle - 90) < 5 || abs(txy_Angle) < 6);
if (fixed_distance <= 3 || fixed_distance > 500)
    distance_status = DISTANCE_BACKWARD;
// 若没有，则接着转向
else if ( fixed_distance < 15 || (!is_direct))
    distance_status = DISTANCE_TURN;
// 若有，则可以直行
else if ( is_direct && fixed_distance >= 15)
{
    if (g_fCarSpeed <= 3)
        stop_counter++;
    else
        stop_counter = 0;
    if (stop_counter >= 100)
    {
        distance_status = FORCED_BACKWARD;
        stop_counter = 0;
    }
    else
        distance_status = DISTANCE_FORWARD;
}
```



